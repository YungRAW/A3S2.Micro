#include "defs.h"

int main(){
   sysinit();
   
   while(1){

   }   
}

